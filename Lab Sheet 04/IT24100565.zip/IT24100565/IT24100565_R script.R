####Exercise
##1.
data<-read.table("Exercise.txt",header=TRUE)
attach(data)
branch_data<-data.frame(data)

##2.
head(branch_data)
str(branch_data)

##3.
boxplot(branch_data$Sales_X1, main="Box Plot for Sales", outpch=8, outline=TRUE, horizontal=FALSE)

##4.
fivenum<- fivenum(branch_data$Advertising_X2)
IQR_value <- IQR(branch_data$Advertising_X2)

> five_number_summary  ##display five number summary
IQR_value   ##display IQR value

##5.
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  # Outlier threshold
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  # Identify outliers
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in the Years_X3 variable
years_outliers <- find_outliers(branch_data$Years_X3)

# Output the result
years_outliers
