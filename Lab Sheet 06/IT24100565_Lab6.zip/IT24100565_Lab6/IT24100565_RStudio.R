###Exercise
##Part 1
#1).
#Binomial distribution
#X∼Binomial(n=50,p=0.85) because 50 independent Bernoulli trials, each has probability 0.85 of passing

#2).
1-pbinom(46,50,0.85,lower.tail = TRUE)

##Part 2
#1).
#Number of customer calls receives in one hour

#2).
#Poisson Distribution   X∼Poisson(λ=12)

#3).
dpois(15,12)