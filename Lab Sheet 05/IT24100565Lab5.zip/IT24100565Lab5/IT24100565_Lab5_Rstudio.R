##Exercise 5
setwd("D:\\SLIIT\\Y2S1\\PS\\IT24100565Lab5")

#1).
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep=",")
fix(Delivery_Times)
attach(Delivery_Times)

#2).
hist(Delivery_Time_.minutes.,main="Histogram for Delivery Times", breaks=seq(20,70,length=10),right=FALSE)

#3).The histogram looks fairly symmetric,with frequencies tapering off on both sides. So, the delivery times follow an approximately normal distribution with a slight tendency toward longer delivery times.

#4).
histogram<-hist(Delivery_Time_.minutes.,main="Histogram for Delivery Times", breaks=seq(20,70,length=10),right=FALSE)

#Cumulative frequency polygon (ogive)
freq <- hist(Delivery_Times$Delivery_Time_minutes, breaks = seq(20, 70, length.out = 10), 
             right = TRUE, plot = FALSE)
cumfreq <- cumsum(freq$counts)
plot(freq$mids, cumfreq, type = "l", main = "Cumulative Frequency Polygon", 
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency")
points(freq$mids, cumfreq)
